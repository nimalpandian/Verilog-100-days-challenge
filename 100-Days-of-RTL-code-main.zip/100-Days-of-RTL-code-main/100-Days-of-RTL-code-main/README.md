# 100-Days-of-RTL-code

Day 1 : Clock Generator

Day 2 : D-Flipflop

Day 3 : JK-Flipflop

Day 4 : 4-Bit Controlled Buffer

Day 5 : Bidirectional Shift Register

Day 6 : Minority Detector

Day 7 : T-Flipflop

Day 8 : Decoder Using Demultiplexer 

Day 9 : Binary to BCD Converter

Day 10 : Binary to Gray Converter

Day 11 : Full Adder using Half Subtractors

Day 12 : Seven Segment Display

Day 13 : Decimal to Binary Encoder

Day 14 : Serial Input Serial Output using D-Flipflop

Day 15 : Digital Clock using BCD Counter

Day 16 : Synchronous Counter 

Day 17 : PISO Shift Register

Day 18 : 4-Bit Parallel Adder

Day 19 : SIPO Shift Register

Day 20 : Johnson Counter

Day 21 : Shift Operations

Day 22 : Modulo-N- Bit-Counter

Day 23 : N-Bit-Parity-Generator

Day 24 : Parameterised Reflected Binary Counter

Day 25 : Multiplexer using Tristate Buffer

Day 26 : Single Port RAM 

Day 27 : N-BIT BCD Adder

Day 28 : Frequency Divider by Odd Number

Day 29 : Dual Port RAM

Day 30 : Greatest Common Divisor

Day 31 : Greatest Common Divisor via Data Path and Controller

Day 32 : Factorial

Day 33 : Sequence Detector(101)- Moore Model

Day 34 : Clock Buffer

Day 35 : Synchronous FIFO

Day 36 : Priority Encoder

Day 37 : Universal Shift Register

Day 38 : Serial Adder

Day 39 : N Bit Comparator

Day 40 : Carry Skip Adder

                                              // System Verilog Codes

Day 41 : TB to print " Hello World " in SV

Day 42 : TB to verify Logic datatype in SV

Day 43 : TB to verify Unpacked Struct datatype in SV

Day 44 : TB to verify Packed Struct datatype in SV

Day 45 : TB to verify Array types in SV

Day 46 : TB to verify Functions in SV

Day 47 : TB to verify Tasks in SV

Day 48 : TB Interface to verify ALU 

Day 49 : TB to verify Object Assignment copy and Shallow copy

Day 50 : TB to verify Deep copy

Day 51 : TB to verify Inheritance

Day 52 : TB to verify Polymorphism

Day 53 : TB to verify Static function and Function Static methods

Day 54 : TB to verify Parameterized Class

Day 55 : TB to verify Randomization

Day 56 : TB to verify Clocking Blocks(Adder circuit)

Day 57 : TB to verify Threads[fork-join_none]

Day 58 : TB to verify Threads[fork-join]

Day 59 : TB to verify Threads[fork-join_any]

Day 60 : TB to verify Events

Day 61 : TB to verify Mailbox(Example-1)

Day 62 : TB for sending transaction data using Mailbox(Example-2)

Day 63 : TB to verify Parameterized Mailbox

Day 64 : TB to verify Semaphore

Day 65 : TB to verify wait-fork

Day 66 : TB to verify Automatic Variables

Day 67 : TB to verify Half Subtractor

Day 68 : TB to verify Full Subtractor

Day 69 : TB to verify Full Adder using Multiplexer

Day 70 : TB to verify SystemVerilog Packages

Day 71 : TB to verify Demultiplexer in SV

Day 72 : TB to verify Callback mechanism in SV

Day 73 : TB to verify Transmission Gate

Day 74 : TB to verify Seven Segment Decoder

Day 75 : TB to verify Parity Generator

Day 76 : TB to verify Inline Constraints

Day 77 : TB to verify Soft Constraints

Day 78 : TB Constraint to generate a pattern 01112131415161718191

Day 79 : TB Constraint to generate a dynamic array with random but unique values without using sv unique constraint

Day 80 : TB to count number of ones in an array

                                               //System Verilog Assertions

Day 81 : Immediate Assertion Example

Day 82 : Concurrent Assertion Example

Day 83 : Sequences in Assertions

Day 84 : System Verilog Assertions Example-1

Day 85 : SVA Overlapped Implication Operator 

Day 86 : SVA Non-Overlapped Implication Operator

Day 87 : System Verilog Assertions Example-2

Day 88 : SVA Consecutive Repetition Operator

Day 89 : SVA Go to Repetition Operator

Day 90 : SVA Non-Consecutive Repetition Operator

Day 91 : System Verilog Assertions Example-3

Day 92 : SVA Sequence Composition - and construct

Day 93 : SVA Sequence Composition - or construct

Day 94 : SVA Sequence Composition - intersect construct

Day 95 : SVA Sequence Composition - throughout construct

Day 96 : SVA Sequence Composition - within construct

Day 97 : SVA Sequence Composition - first_match construct

Day 98 : SVA - Forbidding a property

Day 99 : SVA System Functions

Day 100 : System Verilog Assertions Example-4
